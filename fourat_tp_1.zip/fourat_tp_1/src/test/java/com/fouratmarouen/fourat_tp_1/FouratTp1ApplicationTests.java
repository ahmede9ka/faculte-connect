package com.fouratmarouen.fourat_tp_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FouratTp1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
