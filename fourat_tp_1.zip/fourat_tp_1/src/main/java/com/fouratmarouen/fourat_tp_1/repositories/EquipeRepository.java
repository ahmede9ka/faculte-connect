package com.fouratmarouen.fourat_tp_1.repositories;

import com.fouratmarouen.fourat_tp_1.entities.Equipe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipeRepository extends JpaRepository<Equipe, Long> {
}