package com.fouratmarouen.fourat_tp_1.repositories;

import com.fouratmarouen.fourat_tp_1.entities.Projet;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjetRepository extends JpaRepository<Projet, Long> {

	@Query("select p from Projet p where p.equipe.id = :equipeId")
	List<Projet> findProjetsByEquipeId(@Param("equipeId") Long equipeId);
}