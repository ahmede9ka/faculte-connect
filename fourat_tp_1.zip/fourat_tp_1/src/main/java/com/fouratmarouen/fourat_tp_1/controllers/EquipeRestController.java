package com.fouratmarouen.fourat_tp_1.controllers;

import com.fouratmarouen.fourat_tp_1.entities.Equipe;
import com.fouratmarouen.fourat_tp_1.services.IEquipeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tp5/equipe")
@RequiredArgsConstructor
public class EquipeRestController {

    private final IEquipeService equipeService;

    @GetMapping("/all")
    public List<Equipe> retrieveAllEquipes() {
        return equipeService.retrieveAllEquipes();
    }

    @GetMapping("/{equipeId}")
    public Equipe retrieveEquipe(@PathVariable Long equipeId) {
        return equipeService.retrieveEquipe(equipeId);
    }

    @PostMapping("/add")
    public Equipe addEquipe(@RequestBody Equipe equipe) {
        return equipeService.addEquipe(equipe);
    }

    @PutMapping("/update/{equipeId}")
    public Equipe updateEquipe(@PathVariable Long equipeId, @RequestBody Equipe equipe) {
        return equipeService.updateEquipe(equipeId, equipe);
    }

    @DeleteMapping("/delete/{equipeId}")
    public void deleteEquipe(@PathVariable Long equipeId) {
        equipeService.deleteEquipe(equipeId);
    }
}