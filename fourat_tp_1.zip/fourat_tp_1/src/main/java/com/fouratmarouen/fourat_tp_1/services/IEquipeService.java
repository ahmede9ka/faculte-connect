package com.fouratmarouen.fourat_tp_1.services;

import com.fouratmarouen.fourat_tp_1.entities.Equipe;

import java.util.List;

public interface IEquipeService {

    List<Equipe> retrieveAllEquipes();

    Equipe retrieveEquipe(Long equipeId);

    Equipe addEquipe(Equipe equipe);

    Equipe updateEquipe(Long equipeId, Equipe equipe);

    void deleteEquipe(Long equipeId);
}