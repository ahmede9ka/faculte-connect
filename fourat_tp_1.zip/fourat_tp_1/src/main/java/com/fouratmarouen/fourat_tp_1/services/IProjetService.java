package com.fouratmarouen.fourat_tp_1.services;

import com.fouratmarouen.fourat_tp_1.entities.Projet;

import java.util.List;

public interface IProjetService {

    List<Projet> retrieveAllProjets();

    Projet retrieveProjet(Long projetId);

    List<Projet> retrieveProjetsByEquipe(Long equipeId);

    Projet updateProjet(Long projetId, Projet projet);

    void deleteProjet(Long projetId);

    Projet addProjetAndProjetDetailAndAssign(Projet p);

    void assignProjetDetailToProjet(Long projetId, Long projetDetailId);

    void assignProjetToEquipe(Long projetId, Long equipeId);

    Projet addProjetAndAssignProjetDetail(Projet projet, Long projetDetailId);

    void desaffecterProjetDetail(Long projetId);

    void desaffecterProjetDeEquipe(Long projetId, Long equipeId);
}