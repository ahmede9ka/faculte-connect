package com.fouratmarouen.fourat_tp_1.services;

import com.fouratmarouen.fourat_tp_1.entities.*;
import com.fouratmarouen.fourat_tp_1.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjetServiceImpl implements IProjetService {

    private final ProjetRepository projetRepository;
    private final ProjetDetailRepository projetDetailRepository;
    private final EquipeRepository equipeRepository;

    @Override
    public List<Projet> retrieveAllProjets() {
        return projetRepository.findAll();
    }

    @Override
    public Projet retrieveProjet(Long projetId) {
        return projetRepository.findById(projetId).orElse(null);
    }

    @Override
    public List<Projet> retrieveProjetsByEquipe(Long equipeId) {
        return projetRepository.findProjetsByEquipeId(equipeId);
    }

    @Override
    public Projet updateProjet(Long projetId, Projet projet) {
        Projet existingProjet = projetRepository.findById(projetId).orElse(null);

        if (existingProjet != null) {
            existingProjet.setSujet(projet.getSujet());
            existingProjet.setProjetDetail(projet.getProjetDetail());
            existingProjet.setEquipe(projet.getEquipe());
            return projetRepository.save(existingProjet);
        }

        return null;
    }

    @Override
    public void deleteProjet(Long projetId) {
        projetRepository.deleteById(projetId);
    }

    // ✅ Cas 1
    @Override
    public Projet addProjetAndProjetDetailAndAssign(Projet p) {
        return projetRepository.save(p);
    }

    // ✅ Cas 2
    @Override
    public void assignProjetDetailToProjet(Long projetId, Long projetDetailId) {
        Projet projet = projetRepository.findById(projetId).orElse(null);
        ProjetDetail detail = projetDetailRepository.findById(projetDetailId).orElse(null);

        if (projet != null && detail != null) {
            projet.setProjetDetail(detail);
            projetRepository.save(projet);
        }
    }

    // ✅ Cas 3
    @Override
    public void assignProjetToEquipe(Long projetId, Long equipeId) {
        Projet projet = projetRepository.findById(projetId).orElse(null);
        Equipe equipe = equipeRepository.findById(equipeId).orElse(null);

        if (projet != null && equipe != null) {
            projet.setEquipe(equipe);
            projetRepository.save(projet);
        }
    }

    // ✅ Cas 4
    @Override
    public Projet addProjetAndAssignProjetDetail(Projet projet, Long projetDetailId) {
        ProjetDetail detail = projetDetailRepository.findById(projetDetailId).orElse(null);

        projet.setProjetDetail(detail);
        return projetRepository.save(projet);
    }

    // ✅ Cas 5
    @Override
    public void desaffecterProjetDetail(Long projetId) {
        Projet projet = projetRepository.findById(projetId).orElse(null);

        if (projet != null) {
            projet.setProjetDetail(null);
            projetRepository.save(projet);
        }
    }

    // ✅ Cas 6
    @Override
    public void desaffecterProjetDeEquipe(Long projetId, Long equipeId) {
        Projet projet = projetRepository.findById(projetId).orElse(null);

        if (projet != null) {
            projet.setEquipe(null);
            projetRepository.save(projet);
        }
    }
}