package com.fouratmarouen.fourat_tp_1.repositories;

import com.fouratmarouen.fourat_tp_1.entities.ProjetDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjetDetailRepository extends JpaRepository<ProjetDetail, Long> {
}