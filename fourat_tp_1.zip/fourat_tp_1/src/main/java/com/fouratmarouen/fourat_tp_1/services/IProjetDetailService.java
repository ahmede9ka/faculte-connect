package com.fouratmarouen.fourat_tp_1.services;

import com.fouratmarouen.fourat_tp_1.entities.ProjetDetail;

import java.util.List;

public interface IProjetDetailService {

    List<ProjetDetail> retrieveAllProjetDetails();

    ProjetDetail retrieveProjetDetail(Long projetDetailId);

    ProjetDetail addProjetDetail(ProjetDetail projetDetail);

    ProjetDetail updateProjetDetail(Long projetDetailId, ProjetDetail projetDetail);

    void deleteProjetDetail(Long projetDetailId);
}