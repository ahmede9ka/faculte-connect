package com.fouratmarouen.fourat_tp_1.services;

import com.fouratmarouen.fourat_tp_1.entities.ProjetDetail;
import com.fouratmarouen.fourat_tp_1.repositories.ProjetDetailRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjetDetailServiceImpl implements IProjetDetailService {

    private final ProjetDetailRepository projetDetailRepository;

    @Override
    public List<ProjetDetail> retrieveAllProjetDetails() {
        return projetDetailRepository.findAll();
    }

    @Override
    public ProjetDetail retrieveProjetDetail(Long projetDetailId) {
        return projetDetailRepository.findById(projetDetailId).orElse(null);
    }

    @Override
    public ProjetDetail addProjetDetail(ProjetDetail projetDetail) {
        return projetDetailRepository.save(projetDetail);
    }

    @Override
    public ProjetDetail updateProjetDetail(Long projetDetailId, ProjetDetail projetDetail) {
        ProjetDetail existingProjetDetail = projetDetailRepository.findById(projetDetailId).orElse(null);

        if (existingProjetDetail != null) {
            existingProjetDetail.setDescription(projetDetail.getDescription());
            existingProjetDetail.setTechnologie(projetDetail.getTechnologie());
            existingProjetDetail.setCout(projetDetail.getCout());
            existingProjetDetail.setDateDebut(projetDetail.getDateDebut());
            return projetDetailRepository.save(existingProjetDetail);
        }

        return null;
    }

    @Override
    public void deleteProjetDetail(Long projetDetailId) {
        projetDetailRepository.deleteById(projetDetailId);
    }
}