package com.fouratmarouen.fourat_tp_1.controllers;

import com.fouratmarouen.fourat_tp_1.entities.Projet;
import com.fouratmarouen.fourat_tp_1.services.IProjetService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tp5/projet")
@RequiredArgsConstructor
public class ProjetRestController {

    private final IProjetService projetService;

    @GetMapping("/all")
    public List<Projet> retrieveAllProjets() {
        return projetService.retrieveAllProjets();
    }

    @GetMapping("/{projetId}")
    public Projet retrieveProjet(@PathVariable Long projetId) {
        return projetService.retrieveProjet(projetId);
    }

    @GetMapping("/by-equipe/{equipeId}")
    public java.util.List<Projet> retrieveProjetsByEquipe(@PathVariable Long equipeId) {
        return projetService.retrieveProjetsByEquipe(equipeId);
    }

    @PutMapping("/update/{projetId}")
    public Projet updateProjet(@PathVariable Long projetId, @RequestBody Projet projet) {
        return projetService.updateProjet(projetId, projet);
    }

    @DeleteMapping("/delete/{projetId}")
    public void deleteProjet(@PathVariable Long projetId) {
        projetService.deleteProjet(projetId);
    }

    // Cas 1
    @PostMapping("/ajouter-projet-et-projet-detail")
    public Projet addProjet(@RequestBody Projet p) {
        return projetService.addProjetAndProjetDetailAndAssign(p);
    }

    // Cas 2
    @PutMapping("/affecter-projet-detail-a-projet/{projetId}/{detailId}")
    public void affecterProjetDetail(@PathVariable Long projetId, @PathVariable Long detailId) {
        projetService.assignProjetDetailToProjet(projetId, detailId);
    }

    // Cas 3
    @PutMapping("/affecter-projet-a-equipe/{projetId}/{equipeId}")
    public void affecterProjetEquipe(@PathVariable Long projetId, @PathVariable Long equipeId) {
        projetService.assignProjetToEquipe(projetId, equipeId);
    }

    // Cas 4
    @PostMapping("/ajouter-projet-et-affecter-detail/{detailId}")
    public Projet addProjetAssign(@RequestBody Projet projet, @PathVariable Long detailId) {
        return projetService.addProjetAndAssignProjetDetail(projet, detailId);
    }

    // Cas 5
    @PutMapping("/desaffecter-projet-detail/{projetId}")
    public void desaffecterDetail(@PathVariable Long projetId) {
        projetService.desaffecterProjetDetail(projetId);
    }

    // Cas 6
    @PutMapping("/desaffecter-projet-de-equipe/{projetId}/{equipeId}")
    public void desaffecterEquipe(@PathVariable Long projetId, @PathVariable Long equipeId) {
        projetService.desaffecterProjetDeEquipe(projetId, equipeId);
    }
}