package com.fouratmarouen.fourat_tp_1.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.util.Date;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProjetDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String description;
    private String technologie;
    private Long cout;

    @Temporal(TemporalType.DATE)
    private Date dateDebut;

    @OneToOne(mappedBy = "projetDetail")
    @JsonIgnore
    private Projet projet;
}