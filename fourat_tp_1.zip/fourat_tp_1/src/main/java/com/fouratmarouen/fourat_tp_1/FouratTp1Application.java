package com.fouratmarouen.fourat_tp_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FouratTp1Application {

    public static void main(String[] args) {
        SpringApplication.run(FouratTp1Application.class, args);
    }

}
