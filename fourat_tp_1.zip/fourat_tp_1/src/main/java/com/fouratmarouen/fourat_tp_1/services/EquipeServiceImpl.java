package com.fouratmarouen.fourat_tp_1.services;

import com.fouratmarouen.fourat_tp_1.entities.Equipe;
import com.fouratmarouen.fourat_tp_1.repositories.EquipeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EquipeServiceImpl implements IEquipeService {

    private final EquipeRepository equipeRepository;

    @Override
    public List<Equipe> retrieveAllEquipes() {
        return equipeRepository.findAll();
    }

    @Override
    public Equipe retrieveEquipe(Long equipeId) {
        return equipeRepository.findById(equipeId).orElse(null);
    }

    @Override
    public Equipe addEquipe(Equipe equipe) {
        return equipeRepository.save(equipe);
    }

    @Override
    public Equipe updateEquipe(Long equipeId, Equipe equipe) {
        Equipe existingEquipe = equipeRepository.findById(equipeId).orElse(null);

        if (existingEquipe != null) {
            existingEquipe.setNom(equipe.getNom());
            existingEquipe.setDomaine(equipe.getDomaine());
            return equipeRepository.save(existingEquipe);
        }

        return null;
    }

    @Override
    public void deleteEquipe(Long equipeId) {
        equipeRepository.deleteById(equipeId);
    }
}