package com.fouratmarouen.fourat_tp_1.controllers;

import com.fouratmarouen.fourat_tp_1.entities.ProjetDetail;
import com.fouratmarouen.fourat_tp_1.services.IProjetDetailService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tp5/projet-detail")
@RequiredArgsConstructor
public class ProjetDetailRestController {

    private final IProjetDetailService projetDetailService;

    @GetMapping("/all")
    public List<ProjetDetail> retrieveAllProjetDetails() {
        return projetDetailService.retrieveAllProjetDetails();
    }

    @GetMapping("/{projetDetailId}")
    public ProjetDetail retrieveProjetDetail(@PathVariable Long projetDetailId) {
        return projetDetailService.retrieveProjetDetail(projetDetailId);
    }

    @PostMapping("/add")
    public ProjetDetail addProjetDetail(@RequestBody ProjetDetail projetDetail) {
        return projetDetailService.addProjetDetail(projetDetail);
    }

    @PutMapping("/update/{projetDetailId}")
    public ProjetDetail updateProjetDetail(@PathVariable Long projetDetailId, @RequestBody ProjetDetail projetDetail) {
        return projetDetailService.updateProjetDetail(projetDetailId, projetDetail);
    }

    @DeleteMapping("/delete/{projetDetailId}")
    public void deleteProjetDetail(@PathVariable Long projetDetailId) {
        projetDetailService.deleteProjetDetail(projetDetailId);
    }
}