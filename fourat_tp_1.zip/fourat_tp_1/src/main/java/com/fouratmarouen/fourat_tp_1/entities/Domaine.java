package com.fouratmarouen.fourat_tp_1.entities;

public enum Domaine {
    ERPBI,
    SIM,
    NIDS
}