from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY

output_path = "Compte_Rendu_Fourat_TP_1.pdf"

doc = SimpleDocTemplate(
    output_path,
    pagesize=A4,
    rightMargin=0.75 * inch,
    leftMargin=0.75 * inch,
    topMargin=0.75 * inch,
    bottomMargin=0.75 * inch
)

styles = getSampleStyleSheet()

# Custom styles
title_style = ParagraphStyle(
    'CustomTitle',
    parent=styles['Heading1'],
    fontSize=20,
    textColor='#000080',
    spaceAfter=6,
    alignment=TA_CENTER,
    bold=True
)

subtitle_style = ParagraphStyle(
    'CustomSubtitle',
    parent=styles['Normal'],
    fontSize=12,
    textColor='#333333',
    spaceAfter=24,
    alignment=TA_CENTER,
    italic=True
)

heading1_style = ParagraphStyle(
    'CustomHeading1',
    parent=styles['Heading1'],
    fontSize=14,
    textColor='#000080',
    spaceAfter=12,
    spaceBefore=12,
    bold=True
)

heading2_style = ParagraphStyle(
    'CustomHeading2',
    parent=styles['Heading2'],
    fontSize=12,
    textColor='#1a1a1a',
    spaceAfter=10,
    spaceBefore=10,
    bold=True
)

normal_style = ParagraphStyle(
    'CustomNormal',
    parent=styles['Normal'],
    fontSize=11,
    alignment=TA_JUSTIFY,
    spaceAfter=12
)

bullet_style = ParagraphStyle(
    'CustomBullet',
    parent=styles['Normal'],
    fontSize=11,
    leftIndent=20,
    spaceAfter=6,
    bulletIndent=10
)

story = []

# Title
story.append(Paragraph('Compte rendu du projet Spring Boot', title_style))
story.append(Paragraph('Projet Fourat TP 1', subtitle_style))
story.append(Spacer(1, 0.2 * inch))

# Section 1
story.append(Paragraph('1. Présentation générale', heading1_style))
story.append(Paragraph(
    "Ce projet est une application Spring Boot destinée à gérer des projets, des équipes et les "
    "détails de projet. Il expose une API REST documentée avec Swagger/OpenAPI afin de faciliter "
    "les tests et la consultation des endpoints.",
    normal_style
))

# Section 2
story.append(Paragraph('2. Objectif du projet', heading1_style))
story.append(Paragraph(
    "L'objectif principal est de manipuler trois entités métier liées entre elles : Projet, Equipe "
    "et ProjetDetail. L'application permet de créer, consulter, modifier et supprimer ces éléments, "
    "ainsi que d'affecter ou de désaffecter un projet à une équipe ou à un détail de projet.",
    normal_style
))

# Section 3
story.append(Paragraph('3. Architecture du projet', heading1_style))
story.append(Paragraph(
    "Le projet suit une architecture classique en couches :",
    normal_style
))
story.append(Paragraph('• <b>entities</b> : contient les classes JPA (Projet, Equipe, ProjetDetail, Domaine).', bullet_style))
story.append(Paragraph('• <b>repositories</b> : contient les interfaces Spring Data JPA pour l\'accès à la base de données.', bullet_style))
story.append(Paragraph('• <b>services</b> : contient la logique métier et les opérations CRUD.', bullet_style))
story.append(Paragraph('• <b>controllers</b> : contient les endpoints REST exposés au client ou à Swagger.', bullet_style))

# Section 4
story.append(Paragraph('4. Modèle de données', heading1_style))
story.append(Paragraph(
    "Les relations principales sont les suivantes :",
    normal_style
))
story.append(Paragraph('• Un Projet possède un ProjetDetail en relation OneToOne.', bullet_style))
story.append(Paragraph('• Un Projet appartient à une Equipe en relation ManyToOne.', bullet_style))
story.append(Paragraph('• Une Equipe peut avoir plusieurs Projets en relation OneToMany.', bullet_style))
story.append(Paragraph('• Le champ domaine de Equipe est représenté par une énumération Domaine.', bullet_style))

# Section 5
story.append(Paragraph('5. Fonctionnalités implémentées', heading1_style))
story.append(Paragraph(
    "Les fonctionnalités principales du projet sont :",
    normal_style
))

features = [
    "Ajouter une équipe.",
    "Lister, consulter, modifier et supprimer une équipe.",
    "Ajouter un projet avec ou sans détail de projet.",
    "Lister, consulter, modifier et supprimer un projet.",
    "Affecter un projet à une équipe.",
    "Affecter un détail à un projet.",
    "Désaffecter un projet de son équipe ou de son détail.",
    "Gérer les projets via JPQL, par exemple la récupération des projets d'une équipe."
]

for feature in features:
    story.append(Paragraph(f'• {feature}', bullet_style))

# Section 6
story.append(Spacer(1, 0.15 * inch))
story.append(Paragraph('6. Endpoints REST exposés', heading1_style))
story.append(Paragraph(
    "Les endpoints sont regroupés par entité dans Swagger :",
    normal_style
))

story.append(Paragraph('6.1 Projet', heading2_style))
projet_endpoints = [
    'GET /tp5/projet/all',
    'GET /tp5/projet/{projetId}',
    'GET /tp5/projet/by-equipe/{equipeId}',
    'POST /tp5/projet/ajouter-projet-et-projet-detail',
    'POST /tp5/projet/ajouter-projet-et-affecter-detail/{detailId}',
    'PUT /tp5/projet/affecter-projet-detail-a-projet/{projetId}/{detailId}',
    'PUT /tp5/projet/affecter-projet-a-equipe/{projetId}/{equipeId}',
    'PUT /tp5/projet/desaffecter-projet-detail/{projetId}',
    'PUT /tp5/projet/desaffecter-projet-de-equipe/{projetId}/{equipeId}',
    'PUT /tp5/projet/update/{projetId}',
    'DELETE /tp5/projet/delete/{projetId}',
]
for endpoint in projet_endpoints:
    story.append(Paragraph(f'• {endpoint}', bullet_style))

story.append(Spacer(1, 0.1 * inch))
story.append(Paragraph('6.2 Equipe', heading2_style))
equipe_endpoints = [
    'GET /tp5/equipe/all',
    'GET /tp5/equipe/{equipeId}',
    'POST /tp5/equipe/add',
    'PUT /tp5/equipe/update/{equipeId}',
    'DELETE /tp5/equipe/delete/{equipeId}',
]
for endpoint in equipe_endpoints:
    story.append(Paragraph(f'• {endpoint}', bullet_style))

story.append(Spacer(1, 0.1 * inch))
story.append(Paragraph('6.3 ProjetDetail', heading2_style))
detail_endpoints = [
    'GET /tp5/projet-detail/all',
    'GET /tp5/projet-detail/{projetDetailId}',
    'POST /tp5/projet-detail/add',
    'PUT /tp5/projet-detail/update/{projetDetailId}',
    'DELETE /tp5/projet-detail/delete/{projetDetailId}',
]
for endpoint in detail_endpoints:
    story.append(Paragraph(f'• {endpoint}', bullet_style))

# Section 7
story.append(Spacer(1, 0.15 * inch))
story.append(Paragraph('7. Swagger / OpenAPI', heading1_style))
story.append(Paragraph(
    "La dépendance springdoc-openapi-starter-webmvc-ui est déjà présente dans le pom.xml. "
    "Une fois l'application lancée, Swagger UI est accessible via l'adresse suivante :",
    normal_style
))
story.append(Paragraph('• http://localhost:8080/swagger-ui/index.html', bullet_style))
story.append(Paragraph(
    "Depuis cette interface, il est possible de tester tous les endpoints GET, POST, PUT et DELETE "
    "avec des exemples de requêtes JSON.",
    normal_style
))

# Section 8
story.append(Paragraph('8. Remarques techniques', heading1_style))
story.append(Paragraph('• Les relations bidirectionnelles ont été sécurisées avec @JsonIgnore pour éviter les boucles infinies en JSON.', bullet_style))
story.append(Paragraph('• Le projet utilise JPA/Hibernate pour la persistance et MySQL comme base de données.', bullet_style))
story.append(Paragraph('• La configuration Hibernate est en ddl-auto=update pour créer et mettre à jour le schéma automatiquement.', bullet_style))

# Section 9
story.append(Paragraph('9. Conclusion', heading1_style))
story.append(Paragraph(
    "Ce projet montre la mise en place d'une API REST Spring Boot structurée, documentée et testable "
    "via Swagger. Il illustre la gestion des entités métier, des relations JPA et de la logique métier "
    "à travers une architecture en couches.",
    normal_style
))

# Build PDF
doc.build(story)
print(f'Created {output_path}')
