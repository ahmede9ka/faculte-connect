from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

output_path = "Compte_Rendu_Fourat_TP_1.docx"

doc = Document()

# Base style
style = doc.styles['Normal']
style.font.name = 'Arial'
style.font.size = Pt(11)

# Title
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('Compte rendu du projet Spring Boot')
run.bold = True
run.font.size = Pt(18)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('Projet Fourat TP 1')
run.italic = True
run.font.size = Pt(12)

def add_heading(text, level=1):
    doc.add_heading(text, level=level)

def add_bullet(text):
    doc.add_paragraph(text, style='List Bullet')

def add_text(text):
    doc.add_paragraph(text)

add_heading('1. Présentation générale', 1)
add_text(
    "Ce projet est une application Spring Boot destinée à gérer des projets, des équipes et les détails de projet. "
    "Il expose une API REST documentée avec Swagger/OpenAPI afin de faciliter les tests et la consultation des endpoints."
)

add_heading('2. Objectif du projet', 1)
add_text(
    "L’objectif principal est de manipuler trois entités métier liées entre elles : Projet, Equipe et ProjetDetail. "
    "L’application permet de créer, consulter, modifier et supprimer ces éléments, ainsi que d’affecter ou de désaffecter "
    "un projet à une équipe ou à un détail de projet."
)

add_heading('3. Architecture du projet', 1)
add_text(
    "Le projet suit une architecture classique en couches :"
)
add_bullet('entities : contient les classes JPA (Projet, Equipe, ProjetDetail, Domaine).')
add_bullet('repositories : contient les interfaces Spring Data JPA pour l’accès à la base de données.')
add_bullet('services : contient la logique métier et les opérations CRUD.')
add_bullet('controllers : contient les endpoints REST exposés au client ou à Swagger.')

add_heading('4. Modèle de données', 1)
add_text(
    "Les relations principales sont les suivantes :"
)
add_bullet('Un Projet possède un ProjetDetail en relation OneToOne.')
add_bullet('Un Projet appartient à une Equipe en relation ManyToOne.')
add_bullet('Une Equipe peut avoir plusieurs Projets en relation OneToMany.')
add_bullet('Le champ domaine de Equipe est représenté par une énumération Domaine.')

add_heading('5. Fonctionnalités implémentées', 1)
add_text('Les fonctionnalités principales du projet sont :')
add_bullet('Ajouter une équipe.')
add_bullet('Lister, consulter, modifier et supprimer une équipe.')
add_bullet('Ajouter un projet avec ou sans détail de projet.')
add_bullet('Lister, consulter, modifier et supprimer un projet.')
add_bullet('Affecter un projet à une équipe.')
add_bullet('Affecter un détail à un projet.')
add_bullet('Désaffecter un projet de son équipe ou de son détail.')
add_bullet('Gérer les projets via JPQL, par exemple la récupération des projets d’une équipe.')

add_heading('6. Endpoints REST exposés', 1)
add_text('Les endpoints sont regroupés par entité dans Swagger :')

add_heading('6.1 Projet', 2)
for item in [
    'GET /tp5/projet/all',
    'GET /tp5/projet/{projetId}',
    'GET /tp5/projet/by-equipe/{equipeId}',
    'POST /tp5/projet/ajouter-projet-et-projet-detail',
    'POST /tp5/projet/ajouter-projet-et-affecter-detail/{detailId}',
    'PUT /tp5/projet/affecter-projet-detail-a-projet/{projetId}/{detailId}',
    'PUT /tp5/projet/affecter-projet-a-equipe/{projetId}/{equipeId}',
    'PUT /tp5/projet/desaffecter-projet-detail/{projetId}',
    'PUT /tp5/projet/desaffecter-projet-de-equipe/{projetId}/{equipeId}',
    'PUT /tp5/projet/update/{projetId}',
    'DELETE /tp5/projet/delete/{projetId}',
]:
    add_bullet(item)

add_heading('6.2 Equipe', 2)
for item in [
    'GET /tp5/equipe/all',
    'GET /tp5/equipe/{equipeId}',
    'POST /tp5/equipe/add',
    'PUT /tp5/equipe/update/{equipeId}',
    'DELETE /tp5/equipe/delete/{equipeId}',
]:
    add_bullet(item)

add_heading('6.3 ProjetDetail', 2)
for item in [
    'GET /tp5/projet-detail/all',
    'GET /tp5/projet-detail/{projetDetailId}',
    'POST /tp5/projet-detail/add',
    'PUT /tp5/projet-detail/update/{projetDetailId}',
    'DELETE /tp5/projet-detail/delete/{projetDetailId}',
]:
    add_bullet(item)

add_heading('7. Swagger / OpenAPI', 1)
add_text(
    "La dépendance springdoc-openapi-starter-webmvc-ui est déjà présente dans le pom.xml. "
    "Une fois l’application lancée, Swagger UI est accessible via l’adresse suivante :"
)
add_bullet('http://localhost:8080/swagger-ui/index.html')
add_text(
    "Depuis cette interface, il est possible de tester tous les endpoints GET, POST, PUT et DELETE "
    "avec des exemples de requêtes JSON."
)

add_heading('8. Remarques techniques', 1)
add_bullet('Les relations bidirectionnelles ont été sécurisées avec @JsonIgnore pour éviter les boucles infinies en JSON.')
add_bullet('Le projet utilise JPA/Hibernate pour la persistance et MySQL comme base de données.')
add_bullet('La configuration Hibernate est en ddl-auto=update pour créer et mettre à jour le schéma automatiquement.')

add_heading('9. Conclusion', 1)
add_text(
    "Ce projet montre la mise en place d’une API REST Spring Boot structurée, documentée et testable via Swagger. "
    "Il illustre la gestion des entités métier, des relations JPA et de la logique métier à travers une architecture en couches."
)

doc.save(output_path)
print(f'Created {output_path}')